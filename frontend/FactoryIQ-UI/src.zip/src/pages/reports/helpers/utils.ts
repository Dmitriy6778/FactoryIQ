// src/pages/reports/helpers/utils.ts

export function toSqlDatetime(dateStr: string): string {
  if (!dateStr) return "";
  return dateStr + " 00:00:00";
}

export function getShiftByTimeGroup(dt: string): string {
  if (!dt) return "-";
  const h = Number(dt.slice(11, 13));
  return h >= 8 && h < 20 ? "Дневная" : "Ночная";
}
