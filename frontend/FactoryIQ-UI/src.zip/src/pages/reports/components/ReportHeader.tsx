// src/pages/reports/components/ReportHeader.tsx
import styles from "../styles/CreateReportPage.module.css";
import { ReportTemplate } from "../types";
import {
  presetToday,
  presetYesterday,
  presetCurrentWeek,
  presetPrevWeek,
  presetCurrentMonth
} from "../helpers/datePresets";

interface Props {
  reportType: string;
  onReportTypeChange: (type: string) => void;

  templates: ReportTemplate[];
  selectedTemplateId: number | null;
  onTemplateChange: (id: number | null) => void;

  onApplyPreset: (from: string, to: string) => void;

  onBuildClick: () => void;
}

export default function ReportHeader({
  reportType,
  onReportTypeChange,
  templates,
  selectedTemplateId,
  onTemplateChange,
  onApplyPreset,
  onBuildClick
}: Props) {
  return (
    <>
      <div className={styles.reportSectionTitle}>Тип отчёта</div>

      <select
        className={styles.reportSelect}
        value={reportType}
        onChange={(e) => onReportTypeChange(e.target.value)}
        style={{ width: 280 }}
      >
        <option value="balance">Балансовый отчёт (смены + сутки)</option>
        <option value="custom">Настраиваемый отчёт</option>
      </select>

      {/* --- Выбор шаблона --- */}
      <div className={styles.reportSectionTitleMini} style={{ marginTop: 12 }}>
        Быстрый выбор шаблона
      </div>

      <select
        className={styles.reportSelect}
        value={selectedTemplateId ?? ""}
        onChange={(e) =>
          onTemplateChange(e.target.value ? Number(e.target.value) : null)
        }
        style={{ width: 380 }}
      >
        <option value="">— Без шаблона —</option>
        {templates.map((t) => (
          <option key={t.id} value={t.id}>
            {t.name}
          </option>
        ))}
      </select>

      {/* --- Быстрые периоды --- */}
      <div className={styles.reportSectionTitleMini} style={{ marginTop: 16 }}>
        Быстрый выбор периода
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        <button
          className={styles.reportSmallBtn}
          onClick={() => {
            const p = presetToday();
            onApplyPreset(p.from, p.to);
          }}
        >
          Сегодня
        </button>
        <button
          className={styles.reportSmallBtn}
          onClick={() => {
            const p = presetYesterday();
            onApplyPreset(p.from, p.to);
          }}
        >
          Вчера
        </button>
        <button
          className={styles.reportSmallBtn}
          onClick={() => {
            const p = presetCurrentWeek();
            onApplyPreset(p.from, p.to);
          }}
        >
          Текущая неделя
        </button>
        <button
          className={styles.reportSmallBtn}
          onClick={() => {
            const p = presetPrevWeek();
            onApplyPreset(p.from, p.to);
          }}
        >
          Прошлая неделя
        </button>
        <button
          className={styles.reportSmallBtn}
          onClick={() => {
            const p = presetCurrentMonth();
            onApplyPreset(p.from, p.to);
          }}
        >
          Текущий месяц
        </button>
      </div>

      {/* --- Кнопка построить --- */}
      <div style={{ marginTop: 18 }}>
        <button
          className={styles.reportButton}
          onClick={onBuildClick}
        >
          Построить отчёт
        </button>
      </div>
    </>
  );
}
