// src/pages/reports/components/TagSelector.tsx

import { useState, useRef } from "react";
import styles from "../styles/CreateReportPage.module.css";
import { Tag } from "../types";

interface Props {
  allTags: Tag[];
  selectedTags: Tag[];
  onSelectTag: (tag: Tag) => void;
  onRemove: (id: number) => void;
}

export default function TagSelector({
  allTags,
  selectedTags,
  onSelectTag,
  onRemove
}: Props) {
  const [filter, setFilter] = useState("");
  const [open, setOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const filtered = allTags.filter(
    (t) =>
      !selectedTags.some((s) => s.id === t.id) &&
      (t.name.toLowerCase().includes(filter.toLowerCase()) ||
        t.description?.toLowerCase().includes(filter.toLowerCase()))
  );

  return (
    <div className={styles.tagSearchBlock}>
      <input
        ref={inputRef}
        type="text"
        className={styles.reportInput}
        placeholder="Поиск тега..."
        value={filter}
        onChange={(e) => {
          setFilter(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onBlur={() => setTimeout(() => setOpen(false), 150)}
      />

      {open && (
        <div className={styles.dropdownList}>
          {filtered.length === 0 ? (
            <div className={styles.dropdownEmpty}>Нет тегов</div>
          ) : (
            filtered.slice(0, 40).map((tag) => (
              <div
                key={tag.id}
                className={styles.dropdownItem}
                onMouseDown={() => onSelectTag(tag)}
              >
                <span className={styles.dropdownTagName}>
                  {tag.browse_name || tag.name}
                </span>
                {tag.description && (
                  <span className={styles.dropdownTagDesc}>{tag.description}</span>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {/* выбранные теги */}
      <div className={styles.reportTagRow}>
        {selectedTags.map((t) => (
          <div key={t.id} className={styles.reportTagBox}>
            {t.description || t.name}
            <span onClick={() => onRemove(t.id)}>×</span>
          </div>
        ))}
      </div>
    </div>
  );
}
