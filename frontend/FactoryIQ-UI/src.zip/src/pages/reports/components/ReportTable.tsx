// src/pages/reports/components/ReportTable.tsx

import styles from "../styles/CreateReportPage.module.css";
import { GroupedRow, Totals } from "../helpers/reportTransform";
import { cleanTagName } from "../helpers/reportTransform";

interface Props {
  rows: GroupedRow[];
  tagNames: string[];
  totals: Totals;
  viewMode: "shift" | "daily" | "both";
  onModeChange: (m: "shift" | "daily" | "both") => void;
}

export default function ReportTable({
  rows,
  tagNames,
  totals,
  viewMode,
  onModeChange
}: Props) {
  return (
    <div className={styles.reportWideTableBlock}>
      {/* селектор режима */}
      <div style={{ marginBottom: 10 }}>
        <select
          className={styles.reportSelect}
          value={viewMode}
          onChange={(e) => onModeChange(e.target.value as any)}
          style={{ width: 220 }}
        >
          <option value="shift">Только смены</option>
          <option value="daily">Только сутки</option>
          <option value="both">Смены + сутки</option>
        </select>
      </div>

      <table className={styles.reportWideTable}>
        <thead>
          <tr>
            <th>Дата</th>
            <th>Смена</th>
            {tagNames.map((t) => (
              <th key={t}>{cleanTagName(t)}</th>
            ))}
          </tr>
        </thead>

        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              <td>{row.Date}</td>
              <td>{row["Смена"]}</td>
              {tagNames.map((tn) => (
                <td key={tn}>{row[cleanTagName(tn)] ?? "-"}</td>
              ))}
            </tr>
          ))}

          {/* итоги */}
          <tr
            style={{
              position: "sticky",
              bottom: 0,
              background: "#eaffea",
              fontWeight: "bold"
            }}
          >
            <td colSpan={2}>Итого</td>
            {tagNames.map((t) => (
              <td key={t}>{totals[cleanTagName(t)] ?? 0}</td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
