// src/pages/reports/types.ts

// ----------------------
// OPC / Tag
// ----------------------
export interface Tag {
  id: number;
  name: string;
  browse_name?: string;
  description?: string;
  node_id?: string;
  path?: string;
  data_type?: string;
}

// ----------------------
// Template entries
// ----------------------
export interface ReportTemplateTag {
  tag_id: number;
  tag_type: "counter" | "current";
  aggregate: "" | "SUM" | "AVG" | "MIN" | "MAX";
  interval_minutes: number;
  display_order: number;
}

// ----------------------
// Report template
// ----------------------
export interface ReportTemplate {
  id: number;
  name: string;
  description?: string;
  report_type?: string;     // 'balance' | 'custom'
  period_type?: string;
  is_shared?: boolean;
  auto_schedule?: boolean;
  target_channel?: string | null;

  tags?: ReportTemplateTag[];
}
