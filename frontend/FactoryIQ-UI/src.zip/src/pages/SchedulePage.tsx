// src/pages/SchedulePage.tsx
import React, { useEffect, useMemo, useState, useRef, useCallback } from "react";
import styles from "../styles/SchedulePage.module.css";
import { Send, Edit2, Trash2, Plus, Copy, RefreshCw, Power, Eye, Palette } from "lucide-react";
import {
    Modal,
    Form,
    Input,
    Select,
    TimePicker,
    Table,
    Button,
    Popconfirm,
    Space,
    Tag,
    message,
} from "antd";
import type { ColumnsType } from "antd/es/table";
import type { FormInstance } from "antd/es/form";
import dayjs from "dayjs";
import BackButton from "../components/BackButton";
import ReportPreview from "../components/ReportPreview";
import StyleModal from "../components/StyleModal";

// ====== локальный флажок для отладки (чтобы легко погасить логи) ======
const DEBUG = false;

// ====== словари отображения ======
const PERIOD_LABELS: Record<string, string> = {
    shift: "Смена",
    daily: "Сутки",
    weekly: "Неделя",
    monthly: "Месяц",
    once: "Однократно",
    hourly: "Каждый час",
};

const FORMAT_LABELS: Record<string, string> = {
    chart: "График",
    table: "Таблица",
    file: "Файл",
    text: "Текст",
};

const AGGREGATION_LABELS: Record<string, string> = {
    avg: "Среднее",
    min: "Минимум",
    max: "Максимум",
    sum: "Сумма",
    current: "Текущее",
    delta: "Прирост",
    alerts: "Аварии",
    null: "—",
};

// ====== типы ======
type Task = {
    id: number;
    template_id: number;
    template_name: string;
    period_type: string;
    time_of_day: string | null;
    next_run: string | null;
    last_run: string | null;
    active: boolean;
    target_type: string;
    target_value: string;
    aggregation_type: string | null;
    send_format: string | null;
};

type Template = { id: number; name: string };

// ====== редактируемые ячейки (AntD pattern) ======
const EditableContext = React.createContext<FormInstance<any> | null>(null);

const EditableRow: React.FC<React.HTMLAttributes<HTMLTableRowElement>> = ({ ...props }) => {
    const [form] = Form.useForm();
    return (
        <Form form={form} component={false}>
            <EditableContext.Provider value={form}>
                <tr {...props} />
            </EditableContext.Provider>
        </Form>
    );
};

type EditableCellProps = {
    title: React.ReactNode;
    editable: boolean;
    children: React.ReactNode;
    dataIndex: keyof Task;
    record: Task;
    handleSave: (row: Task) => void;
    inputType?: "input" | "select" | "multiselect" | "time";
    options?: { value: string; label: string }[];
};

const EditableCell: React.FC<EditableCellProps> = ({
    editable,
    children,
    dataIndex,
    record,
    handleSave,
    inputType,
    options = [],
    ...restProps

}) => {
    const [editing, setEditing] = useState(false);
    const inputRef = useRef<any>(null);
    const form = React.useContext(EditableContext)!;

    useEffect(() => {
        if (editing && inputRef.current) inputRef.current?.focus?.();
    }, [editing]);

    const toggleEdit = () => {
        setEditing((e) => !e);
        // заранее приводим TimePicker к dayjs
        if (inputType === "time") {
            form.setFieldsValue({
                [dataIndex]: record[dataIndex]
                    ? dayjs(String(record[dataIndex]), "HH:mm:ss")
                    : null,
            });
        } else {
            form.setFieldsValue({ [dataIndex]: record[dataIndex] });
        }
    };

    const save = async () => {
        try {
            const values = await form.validateFields();
            if (inputType === "time" && values[dataIndex]) {
                values[dataIndex] = values[dataIndex].format("HH:mm:ss");
            }
            setEditing(false);
            handleSave({ ...record, ...values });
        } catch {
            /* noop */
        }
    };

    const { title: _ignoredTitle, ...cellTdProps } = restProps as any;

    // если не редактируемая ячейка
    if (!editable) {
        return <td {...cellTdProps}>{children}</td>;
    }
    let inputNode: React.ReactNode = null;

    switch (inputType) {
        case "select":
            inputNode = (
                <Select
                    ref={inputRef}
                    style={{ minWidth: 110 }}
                    onBlur={save}
                    options={options}
                />
            );
            break;
        case "multiselect":
            inputNode = (
                <Select
                    ref={inputRef}
                    mode="multiple"
                    allowClear
                    style={{ minWidth: 160 }}
                    onBlur={save}
                    options={options}
                />
            );
            break;
        case "time":
            inputNode = (
                <TimePicker ref={inputRef} format="HH:mm:ss" style={{ minWidth: 120 }} onBlur={save} />
            );
            break;
        default:
            inputNode = <Input ref={inputRef} onPressEnter={save} onBlur={save} />;
    }

    return (
        <td {...cellTdProps}>
            {editing ? (
                <Form.Item style={{ margin: 0 }} name={dataIndex as string}>
                    {inputNode}
                </Form.Item>
            ) : (
                <div style={{ minHeight: 24, cursor: "pointer" }} onClick={toggleEdit}>
                    {children}
                    <Edit2 size={12} style={{ marginLeft: 6, color: "#3e75d6" }} />
                </div>
            )}
        </td>
    );
};

// ====== страница ======
const SchedulePage: React.FC = () => {
    const [tasks, setTasks] = useState<Task[]>([]);
    const [templates, setTemplates] = useState<Template[]>([]);
    const [loading, setLoading] = useState(false);

    // модал добавления
    const [modalOpen, setModalOpen] = useState(false);
    const [form] = Form.useForm();

    // предпросмотр
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewProps, setPreviewProps] = useState<any>(null);

    // зависимые поля формы добавления
    const [sendFormat, setSendFormat] = useState<string>("chart");
    const [aggregationType, setAggregationType] = useState<string[]>([]);

    // модал стиля
    const [styleModalOpen, setStyleModalOpen] = useState(false);
    const [styleTemplateId, setStyleTemplateId] = useState<number | null>(null);
    const [stylePreview, setStylePreview] = useState<any>(null);

    // ====== загрузка заданий ======
    const loadTasks = useCallback(async () => {
        setLoading(true);
        try {
            const resp = await fetch("http://localhost:8000/telegram/tasks");
            const data = await resp.json();
            if (DEBUG) console.log("Загруженные задания (tasks):", data.tasks);
            setTasks(data.tasks || []);
        } catch {
            message.error("Ошибка загрузки заданий");
        }
        setLoading(false);
    }, []);

    useEffect(() => {
        loadTasks();
    }, [loadTasks]);

    

    // ====== обработчики ======
    const openStyleModal = useCallback((r: Task) => {
        if (DEBUG) console.log("openStyleModal", r);
        setStyleTemplateId(r.template_id);
        setStylePreview({
            format: (r.send_format as any) || "chart",
            period_type: r.period_type,
            time_of_day: r.period_type === "shift" ? r.time_of_day || "08:00:00" : null,
            aggregation_type: r.aggregation_type || undefined,
        });
        setStyleModalOpen(true);
    }, []);

    const handleSave = useCallback(
        async (row: Task) => {
            setLoading(true);
            try {
                const prepared = {
                    id: row.id,
                    template_id: row.template_id,
                    period_type: row.period_type,
                    time_of_day: row.time_of_day ?? null,
                    target_type: row.target_type,
                    target_value: row.target_value,
                    aggregation_type: Array.isArray(row.aggregation_type)
                        ? row.aggregation_type.join(",")
                        : row.aggregation_type,
                    send_format: row.send_format,
                };

                const resp = await fetch(`http://localhost:8000/telegram/tasks/${row.id}`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(prepared),
                });

                if (!resp.ok) throw new Error();
                message.success("Задание обновлено");
                await loadTasks();
            } catch {
                message.error("Ошибка при обновлении задания");
            }
            setLoading(false);
        },
        [loadTasks]
    );

    const handlePreview = useCallback((record: Task) => {
        if (DEBUG) console.log("Открытие предпросмотра, задача:", record);
        setPreviewProps({
            templateId: record.template_id,
            format: record.send_format || "chart",
            scheduleType: record.period_type,
            scheduleTime: record.period_type === "shift" ? record.time_of_day || "08:00:00" : null,
            aggregationType: record.aggregation_type,
        });
        setPreviewOpen(true);
    }, []);

    const loadTemplates = useCallback(async () => {
        try {
            const resp = await fetch("http://localhost:8000/reports/templates");
            const data = await resp.json();
            setTemplates(data.templates || []);
        } catch {
            message.error("Ошибка загрузки шаблонов");
        }
    }, []);

    const openModal = useCallback(() => {
        loadTemplates();
        setModalOpen(true);
    }, [loadTemplates]);

    const handleActivate = useCallback(
        async (id: number) => {
            setLoading(true);
            try {
                const resp = await fetch(`http://localhost:8000/telegram/tasks/${id}/activate`, {
                    method: "POST",
                });
                if (!resp.ok) throw new Error();
                message.success("Задание включено");
                await loadTasks();
            } catch {
                message.error("Ошибка при включении задания");
            }
            setLoading(false);
        },
        [loadTasks]
    );

    const handleDelete = useCallback(
        async (id: number) => {
            setLoading(true);
            try {
                const resp = await fetch(`http://localhost:8000/telegram/tasks/${id}`, {
                    method: "DELETE",
                });
                if (!resp.ok) throw new Error();
                message.success("Задание удалено");
                await loadTasks();
            } catch {
                message.error("Ошибка при удалении");
            }
            setLoading(false);
        },
        [loadTasks]
    );

    const handleAddTask = useCallback(
        async (values: any) => {
            setLoading(true);
            try {
                const {
                    template_id,
                    period_type,
                    time_of_day,
                    target_type,
                    target_value,
                    send_format,
                    aggregation_type,
                } = values;

                const aggValue = Array.isArray(aggregation_type)
                    ? aggregation_type.join(",")
                    : aggregation_type || null;

                if (period_type === "shift") {
                    // создаём два расписания — 08:00 и 20:00
                    const shiftTimes = ["08:00:00", "20:00:00"];
                    const results: any[] = [];
                    for (const time of shiftTimes) {
                        const resp = await fetch("http://localhost:8000/telegram/schedule", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                                template_id,
                                period_type,
                                time_of_day: time,
                                target_type,
                                target_value: String(target_value),
                                aggregation_type: aggValue,
                                send_format,
                            }),
                        });
                        results.push(await resp.json());
                    }
                    if (results.every((r) => r.ok)) {
                        message.success("Задания по сменам успешно созданы");
                        setModalOpen(false);
                        form.resetFields();
                        await loadTasks();
                    } else if (results.some((r) => String(r?.detail || "").includes("существует"))) {
                        message.warning("Некоторые сменные расписания уже существуют");
                    } else {
                        message.error("Ошибка при создании одного из сменных расписаний");
                    }
                } else {
                    // вычисляем time_of_day в зависимости от периода
                    let timeStr = "";
                    if (period_type === "daily" || period_type === "once") {
                        timeStr =
                            typeof time_of_day === "string"
                                ? time_of_day.length === 5
                                    ? time_of_day + ":00"
                                    : time_of_day
                                : time_of_day?.format("HH:mm:ss");
                    } else if (period_type === "hourly") {
                        timeStr = "00:00:00";
                    } else {
                        timeStr = time_of_day?.format("HH:mm:ss");
                    }

                    const resp = await fetch("http://localhost:8000/telegram/schedule", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                            template_id,
                            period_type,
                            time_of_day: timeStr,
                            target_type,
                            target_value: String(target_value),
                            aggregation_type: aggValue,
                            send_format,
                        }),
                    });

                    if (resp.status === 409) {
                        message.warning("Такое расписание уже существует");
                    } else if (!resp.ok) {
                        message.error("Ошибка при добавлении задания");
                    } else {
                        message.success("Задание добавлено");
                        setModalOpen(false);
                        form.resetFields();
                        await loadTasks();
                    }
                }
            } catch {
                message.error("Ошибка при добавлении задания");
            }
            setLoading(false);
        },
        [form, loadTasks]
    );

    // ====== конфиг для мультиселекта агрегаций ======
    const aggregationSelectProps = useMemo(
        () =>
            sendFormat === "chart"
                ? { allowClear: true, maxTagCount: 1 as const }
                : { allowClear: true, maxTagCount: 4 as const, mode: "multiple" as const },
        [sendFormat]
    );

    // ====== колонки таблицы (мемоизированы) ======
    const columns: ColumnsType<Task> = useMemo(
        () => [
            { title: "ID", dataIndex: "id", width: 60 },
            { title: "Шаблон", dataIndex: "template_name" },
            {
                title: "Время",
                dataIndex: "time_of_day",
                editable: true as any,
                inputType: "time" as const,
                render: (t: string) => t || <span className={styles.gray}>—</span>,
            },
            {
                title: "Период",
                dataIndex: "period_type",
                render: (t: string) => PERIOD_LABELS[t] || t,
            },
            {
                title: "Канал",
                dataIndex: "target_value",
                editable: true as any,
                inputType: "input" as const,
            },
            {
                title: "Формат",
                dataIndex: "send_format",
                editable: true as any,
                inputType: "select" as const,
                options: [
                    { value: "chart", label: "График" },
                    { value: "table", label: "Таблица" },
                    { value: "file", label: "Файл" },
                    { value: "text", label: "Текст" },
                ],
                render: (t: string) => (t ? FORMAT_LABELS[t] || t : <span className={styles.gray}>—</span>),
            },
            {
                title: "Агрегация",
                dataIndex: "aggregation_type",
                editable: true as any,
                inputType: "multiselect" as const,
                options: [
                    { value: "avg", label: "Среднее" },
                    { value: "min", label: "Минимум" },
                    { value: "max", label: "Максимум" },
                    { value: "current", label: "Текущее" },
                ],
                render: (t: string) =>
                    t ? (
                        t.split(",").map((k) => <Tag key={k}>{AGGREGATION_LABELS[k] || k}</Tag>)
                    ) : (
                        <span className={styles.gray}>—</span>
                    ),
            },
            {
                title: "След. запуск",
                dataIndex: "next_run",
                render: (t: string | null) => t || <span className={styles.gray}>—</span>,
            },
            {
                title: "Статус",
                align: "center",
                render: (_: any, r: Task) =>
                    r.active ? <Tag color="green">Активно</Tag> : <Tag color="red">Отключено</Tag>,
            },
            {
                title: "Операции",
                align: "center",
                width: 180,
                render: (_: any, r: Task) => (
                    <Space>
                        <Button
                            size="small"
                            icon={<Eye size={16} />}
                            onClick={() => handlePreview(r)}
                            title="Предпросмотр"
                            style={{ color: "#3e75d6" }}
                        />
                        <Button
                            size="small"
                            icon={<Palette size={16} />}
                            onClick={() => openStyleModal(r)}
                            title="Настроить стиль"
                        />
                        <Button size="small" icon={<Edit2 size={16} />} />
                        {r.active ? (
                            <Popconfirm title="Удалить задание?" onConfirm={() => handleDelete(r.id)}>
                                <Button size="small" icon={<Trash2 size={16} />} danger />
                            </Popconfirm>
                        ) : (
                            <Button
                                size="small"
                                icon={<Power size={16} color="#229ED9" />}
                                onClick={() => handleActivate(r.id)}
                                title="Включить задание"
                            />
                        )}
                        <Button size="small" icon={<Copy size={16} />} />
                    </Space>
                ),
            },
        ],
        [handleActivate, handleDelete, handlePreview, openStyleModal]
    );

    // мерж editable-логики в колонки
    const mergedColumns = useMemo(
        () =>
            columns.map((col: any) =>
                !col.editable
                    ? col
                    : {
                        ...col,
                        onCell: (record: Task) => ({
                            record,
                            editable: col.editable,
                            dataIndex: col.dataIndex,
                            title: col.title,
                            inputType: col.inputType,
                            options: col.options,
                            handleSave,
                        }),
                    }
            ),
        [columns, handleSave]
    );

    return (
        <div className={styles.page}>
            <BackButton />
            <div className={styles.header}>
                <Send size={30} style={{ color: "#229ED9", marginRight: 10 }} />
                <span>Задания на отправку в Telegram</span>
            </div>

            <div className={styles.toolbar}>
                <Button type="primary" icon={<Plus size={18} />} style={{ marginRight: 12 }} onClick={openModal}>
                    Добавить задание
                </Button>
                <Button icon={<RefreshCw size={18} />} onClick={loadTasks} disabled={loading}>
                    Обновить
                </Button>
            </div>

            <div className={styles.tableBlock}>
                <Table<Task>
                    rowKey="id"
                    loading={loading}
                    dataSource={tasks}
                    locale={{ emptyText: "Нет заданий" }}
                    size="middle"
                    bordered
                    pagination={false}
                    columns={mergedColumns as ColumnsType<Task>}
                    components={{
                        body: {
                            row: EditableRow,
                            cell: EditableCell,
                        },
                    }}
                />

                {/* Предпросмотр */}
                <Modal
                    open={previewOpen}
                    title="Предпросмотр отчёта"
                    onCancel={() => setPreviewOpen(false)}
                    footer={null}
                    width={640}
                    styles={{ body: { display: "flex", justifyContent: "center" } }}
                    destroyOnClose
                >
                    {previewProps && (
                        <div style={{ maxWidth: 560, width: "100%" }}>
                            <ReportPreview
                                templateId={previewProps.templateId}
                                format={previewProps.format}
                                scheduleType={previewProps.scheduleType}
                                scheduleTime={previewProps.scheduleTime}
                                aggregationType={previewProps.aggregationType}
                            />
                        </div>
                    )}
                </Modal>
            </div>

            {/* Модал добавления задания */}
            <Modal
                title="Добавить задание"
                open={modalOpen}
                onCancel={() => setModalOpen(false)}
                onOk={() => form.submit()}
                okText="Сохранить"
                cancelText="Отмена"
                confirmLoading={loading}
                destroyOnClose
            >
                <Form
                    form={form}
                    layout="vertical"
                    onFinish={handleAddTask}
                    initialValues={{
                        period_type: "shift",
                        send_format: "chart",
                        target_type: "telegram",
                    }}
                >
                    <Form.Item
                        name="template_id"
                        label="Шаблон"
                        rules={[{ required: true, message: "Выберите шаблон" }]}
                    >
                        <Select
                            placeholder="Выберите шаблон"
                            showSearch
                            optionFilterProp="label"
                            options={templates.map((t) => ({ value: t.id, label: t.name }))}
                        />
                    </Form.Item>

                    <Form.Item
                        name="period_type"
                        label="Период"
                        rules={[{ required: true, message: "Выберите период" }]}
                    >
                        <Select
                            options={[
                                { value: "shift", label: "Смена" },
                                { value: "daily", label: "Сутки" },
                                { value: "weekly", label: "Неделя" },
                                { value: "monthly", label: "Месяц" },
                                { value: "once", label: "Однократно" },
                                { value: "hourly", label: "Каждый час" },
                            ]}
                        />
                    </Form.Item>

                    <Form.Item
                        name="time_of_day"
                        label="Время"
                        rules={[
                            ({ getFieldValue }) => ({
                                validator(_, value) {
                                    if (getFieldValue("period_type") === "shift") return Promise.resolve();
                                    if (!value) return Promise.reject(new Error("Укажите время"));
                                    return Promise.resolve();
                                },
                            }),
                        ]}
                    >
                        <TimePicker format="HH:mm:ss" />
                    </Form.Item>

                    <Form.Item
                        name="target_type"
                        label="Канал"
                        rules={[{ required: true, message: "Выберите канал" }]}
                    >
                        <Select options={[{ value: "telegram", label: "Telegram" }]} />
                    </Form.Item>

                    <Form.Item
                        name="target_value"
                        label="Значение канала"
                        rules={[{ required: true, message: "Введите ID или имя канала" }]}
                    >
                        <Input placeholder="ID или имя канала" />
                    </Form.Item>

                    <Form.Item
                        name="send_format"
                        label="Формат"
                        rules={[{ required: true, message: "Выберите формат" }]}
                    >
                        <Select
                            value={sendFormat}
                            onChange={(val) => {
                                setSendFormat(val);
                                if (val === "chart" && aggregationType.length > 1) {
                                    // для chart — только одна агрегация
                                    const first = aggregationType[0] ? [aggregationType[0]] : [];
                                    setAggregationType(first);
                                    form.setFieldsValue({ aggregation_type: first });
                                }
                            }}
                            options={[
                                { value: "chart", label: "График" },
                                { value: "table", label: "Таблица" },
                                { value: "file", label: "Файл" },
                                { value: "text", label: "Текст" },
                            ]}
                        />
                    </Form.Item>

                    <Form.Item name="aggregation_type" label="Агрегация">
                        <Select
                            {...aggregationSelectProps}
                            value={aggregationType}
                            onChange={(val) => {
                                const arr = Array.isArray(val) ? val : [val];
                                setAggregationType(arr);
                                form.setFieldsValue({ aggregation_type: arr });
                            }}
                            placeholder="Выберите агрегацию"
                            options={[
                                { value: "avg", label: "Среднее" },
                                { value: "min", label: "Минимум" },
                                { value: "max", label: "Максимум" },
                                { value: "current", label: "Текущее" },
                            ]}
                        />
                    </Form.Item>
                </Form>
            </Modal>

            {/* Модал настроек стиля */}
            <StyleModal
                open={styleModalOpen}
                onClose={() => setStyleModalOpen(false)}
                templateId={styleTemplateId || 0}
                preview={stylePreview || { format: "chart", period_type: "weekly" }}
            />
        </div>
    );
};

export default SchedulePage;
