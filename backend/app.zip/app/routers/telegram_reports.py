# backend/app/routers/telegram_reports.py
# Модуль для работы с отчётами в Telegram: создание, предпросмотр, расписания

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any, Tuple
from collections import defaultdict
from datetime import datetime, date, timedelta

import io
import base64

import matplotlib
matplotlib.use("Agg")  # важно: выбрать backend ДО импорта pyplot
import matplotlib.pyplot as plt

import numpy as np
import pandas as pd
import pyodbc

from ..config import get_conn_str
import json  # <-- нужен для load_style_for_template
from .report_styles import ChartStyle, TableStyle, ExcelStyle  # модели стиля

# --------------------------------------------------------------------------------------
# Router
# --------------------------------------------------------------------------------------
router = APIRouter(prefix="/telegram", tags=["telegram"])


# --------------------------------------------------------------------------------------
# Pydantic модели
# --------------------------------------------------------------------------------------
class ChannelCreate(BaseModel):
    channel_id: str
    channel_name: str
    thread_id: Optional[int] = None
    send_as_file: bool = True
    send_as_text: bool = False
    send_as_chart: bool = False
    active: bool = True


class ChannelUpdate(ChannelCreate):
    id: int


class PreviewRequest(BaseModel):
    template_id: int
    format: str  # "file" | "table" | "chart" | "text"
    period_type: str
    time_of_day: Optional[str] = None
    aggregation_type: Optional[str] = None
    style_override: Optional[dict] = None  # <- разовый стиль из модалки

class ReportScheduleCreate(BaseModel):
    template_id: int
    period_type: str
    time_of_day: str
    target_type: str
    target_value: str
    aggregation_type: Optional[str] = None
    send_format: Optional[str] = None


class ReportTaskCreate(BaseModel):
    template_id: int
    period_type: str
    time_of_day: str
    target_type: str
    target_value: str
    aggregation_type: Optional[str] = None
    send_format: Optional[str] = None


class ReportTaskUpdate(ReportTaskCreate):
    id: int


# --------------------------------------------------------------------------------------
# Утилиты БД/дат
# --------------------------------------------------------------------------------------
def _db() -> pyodbc.Connection:
    """Подключение к БД с автокоммитом выключенным (используем вручную)."""
    return pyodbc.connect(get_conn_str())


def _rows_to_dicts(cursor: pyodbc.Cursor) -> Tuple[List[str], List[Dict[str, Any]]]:
    cols = [col[0] for col in cursor.description]
    data = [dict(zip(cols, row)) for row in cursor.fetchall()]
    return cols, data


def _as_date_str(v: Any) -> str:
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    s = str(v or "")  # ожидаем YYYY-MM-DD или с временем
    return s[:10]


def _fmt_tons(v: Any) -> str:
    try:
        f = float(v or 0.0)
    except Exception:
        f = 0.0
    return f"{f:,.1f}".replace(",", " ")


def _is_raw(name: str) -> bool:
    s = (name or "").lower()
    return "вход" in s or "подсолнеч" in s or "seed" in s


# --------------------------------------------------------------------------------------
# Каналы Telegram
# --------------------------------------------------------------------------------------
@router.get("/channels")
def get_channels():
    try:
        with _db() as conn:
            cur = conn.cursor()
            cur.execute("""
                SELECT Id, ChannelId, ChannelName, ThreadId,
                       SendAsFile, SendAsText, SendAsChart, Active
                FROM TelegramReportTarget
                WHERE Active = 1
            """)
            channels: List[Dict[str, Any]] = []
            for row in cur.fetchall():
                channels.append({
                    "id": row.Id,
                    "channel_id": row.ChannelId,
                    "channel_name": row.ChannelName,
                    "thread_id": row.ThreadId,
                    "send_as_file": bool(row.SendAsFile),
                    "send_as_text": bool(row.SendAsText),
                    "send_as_chart": bool(row.SendAsChart),
                    "active": bool(row.Active),
                })
            return {"ok": True, "channels": channels}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.post("/channels")
def add_channel(channel: ChannelCreate):
    try:
        with _db() as conn:
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO TelegramReportTarget
                    (ChannelId, ChannelName, ThreadId, SendAsFile, SendAsText, SendAsChart, Active)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, channel.channel_id, channel.channel_name, channel.thread_id,
                 int(channel.send_as_file), int(channel.send_as_text),
                 int(channel.send_as_chart), int(channel.active))
            conn.commit()
            return {"ok": True}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.put("/channels/{id}")
def update_channel(id: int, channel: ChannelUpdate):
    try:
        with _db() as conn:
            cur = conn.cursor()
            cur.execute("""
                UPDATE TelegramReportTarget
                SET ChannelId=?, ChannelName=?, ThreadId=?,
                    SendAsFile=?, SendAsText=?, SendAsChart=?, Active=?
                WHERE Id=?
            """, channel.channel_id, channel.channel_name, channel.thread_id,
                 int(channel.send_as_file), int(channel.send_as_text),
                 int(channel.send_as_chart), int(channel.active), id)
            conn.commit()
            return {"ok": True}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.delete("/channels/{id}")
def delete_channel(id: int):
    try:
        with _db() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE TelegramReportTarget SET Active=0 WHERE Id=?", id)
            conn.commit()
            return {"ok": True}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


# --------------------------------------------------------------------------------------
# Вспомогательные функции отчётов
# --------------------------------------------------------------------------------------
def get_tag_ids_for_template(template_id: int, *, as_list: bool = False):
    with _db() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT TagId FROM ReportTemplateTags WHERE TemplateId=?
        """, template_id)
        ids = [row[0] for row in cur.fetchall()]
        return ids if as_list else (",".join(str(x) for x in ids) if ids else None)


def compute_preview_period(period_type: str, time_of_day: Optional[str] = None
                           ) -> Tuple[str, str, str]:
    """Возвращает (date_from, date_to, group_type)."""
    now = datetime.now()
    if period_type in ("once", "hourly"):
        dt_to = now.replace(minute=0, second=0, microsecond=0)
        dt_from = dt_to - timedelta(hours=1)
        return (dt_from.strftime("%Y-%m-%d %H:%M:%S"),
                dt_to.strftime("%Y-%m-%d %H:%M:%S"),
                "hour")
    if period_type in ("day", "daily"):
        return now.strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d"), "day"
    if period_type == "shift":
        return now.strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d"), "shift"
    # fallback
    return now.strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d"), "hour"


def get_balance_proc_and_period(period_type: str) -> Tuple[str, str, str]:
    now = datetime.now()
    if period_type == "shift":
        return "sp_Telegram_BalanceReport_Shift", now.strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d")
    if period_type in ("day", "daily"):
        return "sp_Telegram_BalanceReport_Daily", now.strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d")
    if period_type == "weekly":
        date_to = (now - timedelta(days=now.weekday() + 1)).strftime("%Y-%m-%d")
        date_from = (datetime.strptime(date_to, "%Y-%m-%d") - timedelta(days=6)).strftime("%Y-%m-%d")
        return "sp_Telegram_BalanceReport_Weekly", date_from, date_to
    if period_type == "monthly":
        first_day_this_month = now.replace(day=1)
        last_day_last_month = first_day_this_month - timedelta(days=1)
        return ("sp_Telegram_BalanceReport_Monthly",
                last_day_last_month.replace(day=1).strftime("%Y-%m-%d"),
                last_day_last_month.strftime("%Y-%m-%d"))
    # fallback
    return "sp_Telegram_BalanceReport_Daily", now.strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d")


# --------------------------------------------------------------------------------------
# Текстовая «моно» таблица для Telegram (фолбэк)
# --------------------------------------------------------------------------------------
def make_telegram_table(columns: List[str], rows: List[Dict[str, Any]]) -> str:
    """
    Группировка по дате → внутри список «Продукт | Выход, т».
    Итоги убраны. Таблица моноширинная.
    """
    if not rows:
        return "Нет данных для предпросмотра"

    sample = rows[0]
    date_key = "Date" if "Date" in sample else ("Период" if "Период" in sample else None)
    shift_key = "Смена" if "Смена" in sample else None
    product_key = "TagName" if "TagName" in sample else None
    value_key = ("Выход, т" if "Выход, т" in sample else
                 ("Прирост" if "Прирост" in sample else
                  ("Value" if "Value" in sample else None)))

    if not date_key or not product_key or not value_key:
        header = " | ".join(columns)
        body = "\n".join(" | ".join(str(r.get(c, "")) for c in columns) for r in rows)
        return "Предпросмотр отчёта\n" + header + "\n" + "-" * len(header) + "\n" + body

    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        groups[_as_date_str(r.get(date_key))].append(r)

    out = ["Предпросмотр отчёта", ""]
    for d in sorted(groups.keys()):
        rows_d = groups[d]

        shift_label = None
        if shift_key:
            uniq = {str(r.get(shift_key) or "") for r in rows_d if r.get(shift_key)}
            if len(uniq) == 1:
                only = next(iter(uniq))
                if only and only != "Сутки":
                    shift_label = only

        out.append(f"Дата: {d}" + (f" — Смена: {shift_label}" if shift_label else ""))

        # вычислим ширины
        head_l, head_r = "Продукт", "Выход, т"
        prod_vals = [str(r.get(product_key) or "") for r in rows_d]
        val_vals = [_fmt_tons(r.get(value_key)) for r in rows_d]
        w_prod = max(len(head_l), *(len(s) for s in prod_vals)) if prod_vals else len(head_l)
        w_val = max(len(head_r), *(len(s) for s in val_vals)) if val_vals else len(head_r)

        # шапка
        out.append("─" * w_prod + " " + "─" * (w_val + 2))
        out.append(f"{head_l.ljust(w_prod)} | {head_r.rjust(w_val)}")
        out.append("─" * w_prod + " " + "─" * (w_val + 2))

        # строки
        for p, v in zip(prod_vals, val_vals):
            out.append(f"{p.ljust(w_prod)} | {v.rjust(w_val)}")

        out.append("")  # отступ между днями

    return "\n".join(out).rstrip()


# --------------------------------------------------------------------------------------
# Генерация PNG‑таблиц (по одной картинке на каждую дату)
# --------------------------------------------------------------------------------------
def generate_table_pngs_for_balance(
    rows: List[Dict[str, Any]],
    date_key: str,
    product_key: str = "TagName",
    value_key: str = "Выход, т",
    style: Dict[str, Any] | None = None
) -> List[str]:
    style = style or {}
    head_bg = style.get("header",{}).get("bg","#F6F8FB")
    head_color = style.get("header",{}).get("color","#0F172A")
    font_size = style.get("fontSize", 13)
    zebra = style.get("body",{}).get("zebra", True)
    zebra_color = style.get("body",{}).get("zebraColor","#FAFBFC")
    border_color = style.get("body",{}).get("borderColor","#D9DEE9")

    if not rows:
        return []

    from collections import defaultdict
    by_date: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        d = r.get(date_key)
        if hasattr(d, "strftime"):
            d = d.strftime("%Y-%m-%d")
        elif isinstance(d, str):
            d = d[:10]
        by_date[str(d)].append(r)

    images: List[str] = []
    for d, items in sorted(by_date.items()):
        df = pd.DataFrame([{"Продукт": str(it.get(product_key, "")),
                            "Выход, т": _fmt_tons(it.get(value_key))} for it in items])
        n_rows = len(df)
        fig_w = 5.0
        fig_h = max(1.6, 0.4 * n_rows + 0.8)
        fig, ax = plt.subplots(figsize=(fig_w, fig_h), dpi=150)
        ax.axis("off")

        ax.text(0.0, 1.02, f"Дата: {d}", fontsize=max(9, int(font_size*0.8)), fontweight="bold", transform=ax.transAxes)

        tbl = ax.table(
            cellText=df.values,
            colLabels=df.columns,
            cellLoc="center",
            colLoc="center",
            loc="upper left",
            bbox=[0.0, 0.0, 1.0, 0.9],
            colWidths=[0.65, 0.35],
        )
        tbl.auto_set_font_size(False)
        tbl.set_fontsize(max(8, int(font_size*0.8)))
        tbl.scale(1.0, 0.8)

        for (ri, ci), cell in tbl.get_celld().items():
            cell.set_edgecolor(border_color)
            if ri == 0:
                cell.set_facecolor(head_bg)
                cell._text.set_color(head_color)
                cell._text.set_fontweight("bold")
            else:
                if zebra and ri % 2 == 1:
                    cell.set_facecolor(zebra_color)
            if ci == 0:  # выравнивание левого столбца
                cell._loc = "left"
                cell.PAD = 0.01

        buf = io.BytesIO()
        plt.tight_layout(pad=0.2)
        fig.savefig(buf, format="png", bbox_inches="tight")
        plt.close(fig)
        buf.seek(0)
        images.append(base64.b64encode(buf.read()).decode("utf-8"))

    return images



# --------------------------------------------------------------------------------------
# Генерация PNG‑графика
# --------------------------------------------------------------------------------------
def _wrap_text(text: str, max_len: int = 13) -> str:
    words = str(text).split()
    lines, line = [], ""
    for w in words:
        if len((line + " " + w).strip()) <= max_len:
            line = (line + " " + w).strip()
        else:
            if line:
                lines.append(line)
            line = w
    if line:
        lines.append(line)
    return "\n".join(lines)
def generate_bar_chart_png(series: List[Dict[str, Any]], title: str, style: Dict[str, Any] | None = None) -> Optional[str]:
    if not series:
        return None
    style = style or {}
    # размеры/dpi
    dpi = style.get("dpi", 140)
    size = style.get("size", {"w":1280,"h":600})
    W, H = size.get("w",1280)/dpi, size.get("h",600)/dpi
    fig, ax = plt.subplots(figsize=(W, H), dpi=dpi)

    # палитра
    pal = style.get("palette", {})
    mode = pal.get("type", "single-or-multi")
    single_color = pal.get("singleColor", "#2176C1")
    multi = pal.get("multi") or ["#2176C1","#FFB100","#FF6363","#7FDBB6","#6E44FF","#F25F5C","#007F5C","#F49D37","#A259F7","#3A86FF","#FF5C8A","#FFC43D"]

    # одна ли серия
    unique_tags = {str(s.get("tag", "")) for s in series if s.get("tag") is not None}
    one_series = len(unique_tags) <= 1

    # данные
    x_labels, values = [], []
    for s in series:
        for pt in s["data"]:
            x_labels.append(_wrap_text(str(pt["x"]), max_len=style.get("axes",{}).get("x",{}).get("wrap",13)))
            values.append(float(pt["y"]))

    x = np.arange(len(x_labels))
    width = style.get("bars",{}).get("width", 0.9)

    # цвета
    if mode == "single" or (mode == "single-or-multi" and one_series):
        bar_colors = [single_color] * len(x_labels)
    else:
        bar_colors = [multi[i % len(multi)] for i in range(len(x_labels))]

    rects = ax.bar(x, values, width, color=bar_colors)

    # подписи внутри
    if style.get("bars",{}).get("showValueInside", True):
        prec = style.get("bars",{}).get("valuePrecision", 1)
        for i, r in enumerate(rects):
            h = r.get_height()
            ax.text(r.get_x()+r.get_width()/2, h/2, f"{values[i]:.{prec}f}",
                    ha="center", va="center", fontsize=10, color="white", fontweight="bold")

    # оси
    rot = style.get("axes",{}).get("x",{}).get("rotation", 30)
    ax.set_xticks(x)
    ax.set_xticklabels(x_labels, fontsize=style.get("axes",{}).get("x",{}).get("tickFont",10),
                       fontweight="bold", rotation=rot, ha="right", linespacing=1.2)

    y_label = style.get("axes",{}).get("y",{}).get("label", "Всего, т")
    ax.set_ylabel(y_label)
    if style.get("axes",{}).get("y",{}).get("grid", True):
        ax.yaxis.grid(True, linestyle="--", alpha=0.25)

    # фон/рамки
    bg = style.get("background",{}).get("color", "#FFFFFF")
    fig.patch.set_facecolor(bg)
    ax.set_facecolor(bg)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # заголовок
    title_cfg = style.get("layout",{}).get("title", {"show":True,"upper":True,"fontSize":18})
    if title_cfg.get("show", True):
        t = title.upper() if title_cfg.get("upper", True) else title
        ax.set_title(t, fontsize=title_cfg.get("fontSize", 18))

    buf = io.BytesIO()
    plt.tight_layout()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")

def load_style_for_template(cur, template_id: int, override: dict | None = None) -> dict:
    # 1) style_id из шаблона
    cur.execute("SELECT StyleId FROM ReportTemplates WHERE Id=?", template_id)
    row = cur.fetchone()
    base = None
    if row and getattr(row, "StyleId", None):
        # Пытаемся взять три поля; если ExcelStyle нет — берём два
        try:
            cur.execute("SELECT ChartStyle, TableStyle, ExcelStyle FROM ReportStyles WHERE Id=?", row.StyleId)
            s = cur.fetchone()
            base = {
                "chart": json.loads(s.ChartStyle) if s and s.ChartStyle else {},
                "table": json.loads(s.TableStyle) if s and s.TableStyle else {},
                "excel": json.loads(getattr(s, "ExcelStyle", None)) if s and getattr(s, "ExcelStyle", None) else {}
            }
        except Exception:
            cur.execute("SELECT ChartStyle, TableStyle FROM ReportStyles WHERE Id=?", row.StyleId)
            s = cur.fetchone()
            base = {
                "chart": json.loads(s.ChartStyle) if s and s.ChartStyle else {},
                "table": json.loads(s.TableStyle) if s and s.TableStyle else {},
                "excel": {}
            }

    if not base:
        base = {"chart": ChartStyle().dict(), "table": TableStyle().dict(), "excel": ExcelStyle().dict()}

    # 2) разовый override из payload (если передадим с фронта)
    if override:
        for k in ("chart", "table", "excel"):
            v = override.get(k)
            if isinstance(v, dict):
                base[k].update(v)

    return base


# --------------------------------------------------------------------------------------
# Предпросмотр отчёта
# --------------------------------------------------------------------------------------
@router.post("/preview")
def preview_report(payload: PreviewRequest):
    try:
        table_pngs: Optional[List[str]] = None  # по умолчанию
        with _db() as conn:
            cur = conn.cursor()

            # 1) Тип отчёта и имя шаблона
            cur.execute("SELECT ReportType, Name FROM ReportTemplates WHERE Id=?", payload.template_id)
            row = cur.fetchone()
            if not row:
                return {"ok": False, "detail": "Не найден шаблон отчёта."}
            report_type = row.ReportType or "custom"
            template_name = row.Name or "Предпросмотр отчёта"
            styles = load_style_for_template(cur, payload.template_id, payload.style_override)
            chart_style = styles["chart"]
            table_style = styles["table"]
            excel_style = styles.get("excel", {})  # на будущее
            # 2) Теги для шаблона
            if report_type == "balance":
                tag_ids = get_tag_ids_for_template(payload.template_id, as_list=False)
            else:
                tag_ids = get_tag_ids_for_template(payload.template_id, as_list=True)
            if not tag_ids:
                return {"ok": False, "detail": "Не выбраны теги для шаблона."}

            # 3) Подписи тегов: {BrowseName: Description}
            cur.execute("""
                SELECT t.BrowseName, ISNULL(t.Description, t.BrowseName) AS Label
                FROM OpcTags t
                WHERE t.Id IN (
                    SELECT TagId FROM ReportTemplateTags WHERE TemplateId = ?
                )
            """, payload.template_id)
            tag_label_map = {r.BrowseName: r.Label for r in cur.fetchall()}

            # 4) Данные отчёта (по типу)
            if report_type == "balance":
                if payload.period_type == "weekly":
                    now = datetime.now()
                    this_mon_8 = (now - timedelta(days=now.weekday())).replace(hour=8, minute=0, second=0, microsecond=0)
                    week_end = this_mon_8.date()
                    week_start = (this_mon_8 - timedelta(days=7)).date()
                    proc = "sp_Telegram_BalanceReport_Daily"
                    cur.execute(f"EXEC {proc} ?, ?, ?", week_start, week_end - timedelta(days=1), tag_ids)
                    columns, data = _rows_to_dicts(cur)
                    period = {"date_from": str(week_start), "date_to": str(week_end - timedelta(days=1))}
                else:
                    proc, date_from, date_to = get_balance_proc_and_period(payload.period_type)
                    cur.execute(f"EXEC {proc} ?, ?, ?", date_from, date_to, tag_ids)
                    columns, data = _rows_to_dicts(cur)
                    period = {"date_from": date_from, "date_to": date_to}
            else:
                date_from, date_to, group_type = compute_preview_period(payload.period_type, payload.time_of_day)
                agg_list = [
                    a.strip().upper()
                    for a in (payload.aggregation_type or "CURR").split(",")
                    if a.strip()
                ]
                import json
                tags_json = json.dumps([
                    {"tag_id": int(tid), "aggregates": agg_list, "interval_minutes": 60}
                    for tid in tag_ids  # type: ignore[arg-type]
                ])
                cur.execute("EXEC sp_Telegram_TagValues_MultiAgg ?, ?, ?, ?",
                            date_from, date_to, tags_json, group_type)
                columns, data = _rows_to_dicts(cur)
                period = {"date_from": date_from, "date_to": date_to}

        # 5) Фильтр по смене — только для shift
        if payload.period_type == "shift" and payload.time_of_day:
            t5 = payload.time_of_day[:5]
            shift_no = 1 if t5 == "08:00" else 2 if t5 == "20:00" else None
            if shift_no is not None:
                data = [r for r in data if str(r.get("ShiftNo", "")) == str(shift_no)]
                time_target = datetime.strptime(payload.time_of_day, "%H:%M:%S").time()
                def is_shift_match(row: Dict[str, Any]) -> bool:
                    start = row.get("Начало") or row.get("Start")
                    if isinstance(start, datetime):
                        return start.time().hour == time_target.hour
                    return True
                data = [r for r in data if is_shift_match(r)]

        # 6) Series для графика
        chart_series: List[Dict[str, Any]] = []
        if report_type == "balance" and payload.period_type == "weekly":
            by_date = defaultdict(float)
            for r in data:
                dt = r.get("Date") or r.get("Дата")
                dkey = dt.date() if isinstance(dt, datetime) else datetime.strptime(str(dt), "%Y-%m-%d").date()
                try:
                    by_date[dkey] += float(r.get("Прирост") or 0)
                except Exception:
                    pass

            now = datetime.now()
            this_mon_8 = (now - timedelta(days=now.weekday())).replace(hour=8, minute=0, second=0, microsecond=0)
            ordered_days = [(this_mon_8 - timedelta(days=7) + timedelta(days=i)).date() for i in range(7)]
            chart_series = [{
                "tag": "Всего за день",
                "aggregate": "Value",
                "data": [{"x": f"{['Пн','Вт','Ср','Чт','Пт','Сб','Вс'][d.weekday()]} {d.day:02d}.{d.month:02d}",
                          "y": (by_date.get(d, 0.0) or 0.0) / 1000.0}
                         for d in ordered_days],
            }]
        else:
            if data:
                series_dict: Dict[str, Dict[str, List[Dict[str, Any]]]] = defaultdict(lambda: defaultdict(list))
                for row in data:
                    tag_name = row.get("TagName")
                    tag = tag_label_map.get(tag_name, tag_name)
                    y_raw = row.get("Прирост") if "Прирост" in row else row.get("Value")
                    try:
                        y = float(y_raw) if y_raw is not None else None
                    except Exception:
                        y = None
                    if y is None:
                        continue
                    y = y / 1000.0
                    x = row.get("Date") or row.get("Начало") or row.get("Start") or tag
                    if isinstance(x, datetime):
                        x = x.strftime("%d.%m %H:%M")
                    series_dict[str(tag)]["Value"].append({"x": x, "y": y})

                for tag, aggs in series_dict.items():
                    for agg, points in aggs.items():
                        chart_series.append({"tag": tag, "aggregate": agg, "data": points})

        # 7) Форматирование таблиц (table/text): нормализация + PNG-таблицы (балансовые)
        fmt = (payload.format or "").lower()
        is_table_or_text = fmt in ("table", "text")

        if is_table_or_text and report_type == "balance" and data:
            # Сузим и переименуем поля
            sample = data[0]
            date_key = "Date" if "Date" in sample else ("Период" if "Период" in sample else None)
            shift_key = "Смена" if "Смена" in sample else None

            out_cols = [c for c in [date_key, shift_key, "TagName", "Выход, т"] if c]
            out_rows: List[Dict[str, Any]] = []
            for r in data:
                browse = r.get("TagName")
                label = tag_label_map.get(browse, browse)
                growth = r.get("Прирост") if "Прирост" in r else r.get("Value")
                try:
                    val_t = float(growth or 0) / 1000.0
                except Exception:
                    val_t = None

                newr: Dict[str, Any] = {}
                if date_key:
                    newr[date_key] = r.get(date_key)
                if shift_key:
                    newr["Смена"] = r.get(shift_key)
                newr["TagName"] = label
                newr["Выход, т"] = val_t
                out_rows.append(newr)

            columns = out_cols
            data = out_rows

            # PNG‑таблицы по датам
            date_key_for_img = "Date" if "Date" in columns else "Период"
            table_pngs = generate_table_pngs_for_balance(
                data,
                date_key=date_key_for_img,
                product_key="TagName",
                value_key="Выход, т",
                style=table_style
            )
        # если не баланс или не table/text — columns/data остаются как есть

        # 8) PNG‑график (если есть данные)
        chart_png = generate_bar_chart_png(chart_series, title=template_name, style=chart_style) if chart_series else None


        # 9) Обрезаем лишние ключи в данных под текущие columns
        if columns:
            data = [{k: row.get(k) for k in columns} for row in data]

        return {
            "ok": True,
            "data": data,
            "columns": columns,
            "chart_series": chart_series,
            "chart_png": chart_png,
            "table_pngs": table_pngs,
            "text_table": make_telegram_table(columns, data),
            "period": period,
        }

    except Exception as ex:
        import traceback
        print("Ошибка в preview_report:\n", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Ошибка генерации превью: {ex}")


# --------------------------------------------------------------------------------------
# Расчёт первичного NextRun (для /schedule)
# --------------------------------------------------------------------------------------
def compute_initial_nextrun(period_type: str, time_of_day: Optional[str]) -> datetime:
    now = datetime.now()
    hh, mm, ss = 8, 0, 0
    if time_of_day:
        parts = [int(p) for p in time_of_day.split(":")]
        if len(parts) == 3:
            hh, mm, ss = parts
        elif len(parts) == 2:
            hh, mm = parts
            ss = 0

    if period_type in ("day", "daily"):
        run = now.replace(hour=hh, minute=mm, second=ss, microsecond=0)
        if run <= now:
            run += timedelta(days=1)
    elif period_type == "shift":
        run = now.replace(hour=hh, minute=mm, second=ss, microsecond=0)
        if run <= now:
            run += timedelta(hours=12 if hh in (8, 20) else 12)
    elif period_type == "weekly":
        # следующее наступление того же дня недели / времени
        target = now.replace(hour=hh, minute=mm, second=ss, microsecond=0)
        days_ahead = (7 - now.weekday()) % 7
        if days_ahead == 0 and target <= now:
            days_ahead = 7
        run = (now + timedelta(days=days_ahead)).replace(hour=hh, minute=mm, second=ss, microsecond=0)
    elif period_type == "monthly":
        # первое число следующего месяца, время = hh:mm:ss
        if now.month == 12:
            run = now.replace(year=now.year + 1, month=1, day=1, hour=hh, minute=mm, second=ss, microsecond=0)
        else:
            run = now.replace(month=now.month + 1, day=1, hour=hh, minute=mm, second=ss, microsecond=0)
    elif period_type == "hourly":
        run = (now + timedelta(hours=1)).replace(minute=0, second=0, microsecond=0)
    elif period_type == "once":
        run = now.replace(hour=hh, minute=mm, second=ss, microsecond=0)
        if run <= now:
            run = now  # отправим как можно скорее
    else:
        run = (now + timedelta(days=1)).replace(hour=8, minute=0, second=0, microsecond=0)

    return run


# --------------------------------------------------------------------------------------
# Создание расписания (с проверкой дубликатов) — /schedule
# --------------------------------------------------------------------------------------
@router.post("/schedule")
def create_report_schedule(payload: ReportScheduleCreate):
    try:
        if not payload.target_value:
            raise HTTPException(status_code=400, detail="Не выбран канал или чат для отправки.")

        with _db() as conn:
            cur = conn.cursor()
            cur.execute("""
                SELECT 1 FROM ReportSchedule
                WHERE TemplateId = ?
                  AND PeriodType = ?
                  AND TimeOfDay = ?
                  AND TargetType = ?
                  AND TargetValue = ?
                  AND ISNULL(AggregationType, '') = ISNULL(?, '')
                  AND ISNULL(SendFormat, '') = ISNULL(?, '')
                  AND Active = 1
            """, payload.template_id, payload.period_type, payload.time_of_day,
                 payload.target_type, payload.target_value,
                 payload.aggregation_type, payload.send_format)
            if cur.fetchone():
                raise HTTPException(status_code=409, detail="Такое расписание уже существует.")

            next_run = compute_initial_nextrun(payload.period_type, payload.time_of_day)
            cur.execute("""
                INSERT INTO ReportSchedule
                    (TemplateId, PeriodType, TimeOfDay, NextRun,
                     TargetType, TargetValue, AggregationType, SendFormat, Active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
            """, payload.template_id, payload.period_type, payload.time_of_day, next_run,
                 payload.target_type, payload.target_value, payload.aggregation_type, payload.send_format)
            conn.commit()
            return {"ok": True}
    except HTTPException:
        raise
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


# --------------------------------------------------------------------------------------
# Задачи (grid в UI)
# --------------------------------------------------------------------------------------
@router.get("/tasks")
def get_report_tasks():
    try:
        with _db() as conn:
            cur = conn.cursor()
            cur.execute("""
                SELECT
                    rs.Id,
                    rs.TemplateId,
                    t.Name as TemplateName,
                    rs.PeriodType,
                    rs.TimeOfDay,
                    rs.NextRun,
                    rs.LastRun,
                    rs.Active,
                    rs.TargetType,
                    rs.TargetValue,
                    rs.AggregationType,
                    rs.SendFormat
                FROM OpcUaSystem.dbo.ReportSchedule rs
                LEFT JOIN OpcUaSystem.dbo.ReportTemplates t ON rs.TemplateId = t.Id
                ORDER BY rs.Id DESC
            """)
            tasks: List[Dict[str, Any]] = []
            for row in cur.fetchall():
                tasks.append({
                    "id": row.Id,
                    "template_id": row.TemplateId,
                    "template_name": row.TemplateName,
                    "period_type": row.PeriodType,
                    "time_of_day": str(row.TimeOfDay) if row.TimeOfDay else None,
                    "next_run": str(row.NextRun) if row.NextRun else None,
                    "last_run": str(row.LastRun) if row.LastRun else None,
                    "active": bool(row.Active),
                    "target_type": row.TargetType,
                    "target_value": row.TargetValue,
                    "aggregation_type": row.AggregationType,
                    "send_format": row.SendFormat,
                })
            return {"ok": True, "tasks": tasks}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.post("/tasks")
def create_report_task(payload: ReportTaskCreate):
    try:
        with _db() as conn:
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO ReportSchedule
                    (TemplateId, PeriodType, TimeOfDay, TargetType, TargetValue, AggregationType, SendFormat, Active)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
            """, payload.template_id, payload.period_type, payload.time_of_day,
                 payload.target_type, payload.target_value,
                 payload.aggregation_type, payload.send_format)
            conn.commit()
            return {"ok": True}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.put("/tasks/{id}")
def update_report_task(id: int, payload: ReportTaskUpdate):
    try:
        with _db() as conn:
            cur = conn.cursor()
            cur.execute("""
                UPDATE ReportSchedule
                SET TemplateId=?, PeriodType=?, TimeOfDay=?,
                    TargetType=?, TargetValue=?, AggregationType=?, SendFormat=?
                WHERE Id=? 
            """, payload.template_id, payload.period_type, payload.time_of_day,
                 payload.target_type, payload.target_value,
                 payload.aggregation_type, payload.send_format, id)
            conn.commit()
            return {"ok": True}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.delete("/tasks/{id}")
def delete_report_task(id: int):
    try:
        with _db() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE ReportSchedule SET Active=0 WHERE Id=?", id)
            conn.commit()
            return {"ok": True}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.post("/tasks/{id}/activate")
def activate_report_task(id: int):
    try:
        with _db() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE ReportSchedule SET Active=1 WHERE Id=?", id)
            conn.commit()
            return {"ok": True}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
